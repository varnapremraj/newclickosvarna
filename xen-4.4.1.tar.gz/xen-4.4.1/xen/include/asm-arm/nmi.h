#ifndef ASM_NMI_H
#define ASM_NMI_H

#define register_guest_nmi_callback(a)  (-ENOSYS)
#define unregister_guest_nmi_callback() (-ENOSYS)

#endif /* ASM_NMI_H */
/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
