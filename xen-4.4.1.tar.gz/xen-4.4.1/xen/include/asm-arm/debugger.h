#ifndef __ARM_DEBUGGER_H__
#define __ARM_DEBUGGER_H__

#define debugger_trap_fatal(v, r) ((void) 0)
#define debugger_trap_immediate() ((void) 0)

#endif /* __ARM_DEBUGGER_H__ */
/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
