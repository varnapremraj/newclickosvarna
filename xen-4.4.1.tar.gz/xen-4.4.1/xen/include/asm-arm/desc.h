#ifndef __ARCH_DESC_H
#define __ARCH_DESC_H

#endif /* __ARCH_DESC_H */
/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
