#ifndef _XEN_PAGING_H
#define _XEN_PAGING_H

#define paging_mode_translate(d)              (1)
#define paging_mode_external(d)               (1)

#endif /* XEN_PAGING_H */

/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
