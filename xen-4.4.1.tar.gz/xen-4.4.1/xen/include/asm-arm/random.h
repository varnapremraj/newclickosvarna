#ifndef __ASM_RANDOM_H__
#define __ASM_RANDOM_H__

static inline unsigned int arch_get_random(void)
{
    return 0;
}

#endif /* __ASM_RANDOM_H__ */
