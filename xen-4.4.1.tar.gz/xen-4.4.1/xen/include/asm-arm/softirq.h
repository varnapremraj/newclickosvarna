#ifndef __ASM_SOFTIRQ_H__
#define __ASM_SOFTIRQ_H__

#define NR_ARCH_SOFTIRQS       0

#endif /* __ASM_SOFTIRQ_H__ */
/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
