#ifndef __X86_PCI_H__
#define __X86_PCI_H__

struct arch_pci_dev {
};

#endif /* __X86_PCI_H__ */
