#ifndef _ARM_DELAY_H
#define _ARM_DELAY_H

extern void udelay(unsigned long usecs);

#endif /* defined(_ARM_DELAY_H) */
/*
 * Local variables:
 * mode: C
 * c-file-style: "BSD"
 * c-basic-offset: 4
 * indent-tabs-mode: nil
 * End:
 */
