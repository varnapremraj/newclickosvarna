/******************************************************************************
 * compat.h
 */

#define COMPAT_BITS_PER_LONG 32

typedef uint32_t compat_ptr_t;
typedef unsigned long full_ptr_t;
