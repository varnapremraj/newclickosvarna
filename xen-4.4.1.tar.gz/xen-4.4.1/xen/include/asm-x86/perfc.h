#ifndef __ASM_PERFC_H__
#define __ASM_PERFC_H__

static inline void arch_perfc_reset(void)
{
}

static inline void arch_perfc_gather(void)
{
}

#endif
