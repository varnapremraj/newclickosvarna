#include <xen/types.h>
#include <asm/x86_64/efibind.h>
