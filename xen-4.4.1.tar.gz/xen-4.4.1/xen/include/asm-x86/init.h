#ifndef _XEN_ASM_INIT_H
#define _XEN_ASM_INIT_H

#endif /* _XEN_ASM_INIT_H */
