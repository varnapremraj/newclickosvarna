#ifndef __XEN_RANDOM_H__
#define __XEN_RANDOM_H__

unsigned int get_random(void);

#endif /* __XEN_RANDOM_H__ */
