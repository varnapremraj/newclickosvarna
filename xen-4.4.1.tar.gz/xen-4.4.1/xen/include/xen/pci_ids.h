#define PCI_VENDOR_ID_AMD                0x1022

#define PCI_VENDOR_ID_NVIDIA             0x10de

#define PCI_VENDOR_ID_OXSEMI             0x1415

#define PCI_VENDOR_ID_BROADCOM           0x14e4

#define PCI_VENDOR_ID_INTEL              0x8086
